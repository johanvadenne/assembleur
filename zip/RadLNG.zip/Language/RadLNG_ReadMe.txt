RadASM language development package.
------------------------------------

IMPORTANT!
Language selections can only be done on NT platform.

Copy the *.lng files to RadASM\Language directory.
Use RadASM Options / Language to select your language.

You can create, change and test a language file with the
included tool RadLNG.exe.

If you create a language file that you want to share you
can email it to radasmide@hotmail.com and I will
include it on the RadASM website.

KetilO