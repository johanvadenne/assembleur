Unzip to RadASM root (C:\RadASM) so that fasm.ini, Goasm:ini, masm.ini,
nasm.ini and tasm.ini are in the same directory as RadASM.exe and RadASM.ini.
Then use Options / Programming Languages to add the languages.
